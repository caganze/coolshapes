[![N|Solid](https://travis-ci.org/caganze/shapes.svg?branch=master)](https://travis-ci.org/caganze/shapes/)

# shapes

A tool for manipulating shapes inside a 2-d plot


[working on documentation ](https://caganze.github.io/shapes/#)